function kelvinToCelsius(kelvin) {
    return Math.round(kelvin - 273.15);
}

export default kelvinToCelsius;